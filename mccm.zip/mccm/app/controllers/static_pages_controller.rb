class StaticPagesController < ApplicationController
  def home
  end

  def videos
  end

  def presentations
  end

  def papers
  end

  def results
  end

  def help
  end

  def about
  end

  def index
  	@foo = 'bar'
  end
end
