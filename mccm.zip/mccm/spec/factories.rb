FactoryGirl.define do
	factory :user do
		name "test name"
		email "testemail@gmail.com"
		password "foobar"
		password_confirmation "foobar"
	end
end