# Be sure to restart your server when you modify this file.

Mccm::Application.config.session_store :cookie_store, key: '_mccm_session'
